(() => {
  'use strict';
  if (window.__limboRestart) return;
  window.__limboRestart = true;
  if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) chrome.runtime.onMessage.addListener((m, _s, reply) => {
    if (m.type !== 'limbo-wallet') return;
    const wallets = [...document.querySelectorAll('[data-testid="coin-toggle"][data-active-currency]')].filter(e => e.getClientRects().length);
    if (wallets.length !== 1) return reply({ok:false});
    const raw = wallets[0].textContent.trim().replace(/\s/g,'');
    const amount = /^\d+(?:[.,]\d{1,8})?$/.test(raw) ? Number(raw.replace(',','.')) : NaN;
    reply({ok:Number.isFinite(amount),amount,currency:wallets[0].getAttribute('data-active-currency'),time:Date.now()});
  });
  const host = document.createElement('div');
  host.id = 'limbo-restart-tool';
  const root = host.attachShadow({mode: 'open'});
  root.innerHTML = `<style>
    :host{position:fixed;right:16px;bottom:18px;z-index:2147483647;font:14px Arial;color:#fff}
    section{width:250px;background:#102633;border:1px solid #547184;border-radius:12px;padding:14px;box-shadow:0 4px 24px #0008}
    label{display:block;margin:12px 0 6px}input,button{box-sizing:border-box;padding:9px;border-radius:6px;border:1px solid #547184}
    input{width:100%;background:#071b27;color:white}button{margin-top:10px;cursor:pointer;background:#1475e1;color:white;width:100%}
    p{font-size:12px;line-height:1.5;margin-bottom:0}output{display:block;margin-top:10px;color:#b7e6ff}
  </style><section><strong>Limbo · Tự chạy lại</strong>
  <label for="amount">Tiền cược ban đầu</label><input id="amount" type="number" min="0.00000001" step="0.00000001" value="0.001">
  <label for="tp">TP · Dừng khi đạt lợi nhuận</label><input id="tp" type="number" min="0" step="0.00000001" value="1.1">
  <label for="sl">SL · Dừng khi thua</label><input id="sl" type="number" min="0" step="0.00000001" value="1">
  <button id="toggle">Bật theo dõi</button><output>Đang tắt</output>
  <button id="telegram">Telegram · số dư mỗi 3 phút</button>
  <p>Bật theo dõi rồi tự bấm Bắt Đầu trên game. Khi hoàn thành, chờ 2 giây và chạy lại. Bấm Dừng trên game sẽ tắt theo dõi. F5 cũng tắt.</p></section>`;
  document.documentElement.append(host);
  const amount = root.querySelector('input'), toggle = root.querySelector('button'), status = root.querySelector('output');
  const tp=root.querySelector('#tp'), sl=root.querySelector('#sl');
  root.querySelector('#telegram').onclick=()=>chrome.runtime.sendMessage({type:'open-options'});
  let preparingAt=0;
  let enabled = false, seenRunning = false, idleAt = 0, awaiting = 0, cycles = 0, currency = '', lastButton = null;
  const visible = e => !!e && e.getClientRects().length > 0;
  function controls() {
    const buttons = [...document.querySelectorAll('[data-testid="auto-bet-button"]')].filter(visible);
    const inputs = [...document.querySelectorAll('[data-testid="input-game-amount"]')].filter(visible);
    const profits=[...document.querySelectorAll('[data-testid="stop-on-profit-input"]')].filter(visible);
    const losses=[...document.querySelectorAll('[data-testid="stop-on-loss-input"]')].filter(visible);
    return buttons.length === 1 && inputs.length === 1 && profits.length===1 && losses.length===1 ? {button: buttons[0], input: inputs[0],tp:profits[0],sl:losses[0]} : null;
  }
  const value = text => Number(String(text).replace(',', '.'));
  function off(message) {
    enabled = false; seenRunning = false; idleAt = 0; awaiting = 0;
    preparingAt=0;amount.disabled = tp.disabled = sl.disabled = false; toggle.textContent = 'Bật theo dõi'; status.textContent = message;
  }
  toggle.addEventListener('click', () => {
    if (enabled) return off('Đã tắt tự chạy lại; lượt game đang chạy vẫn tiếp tục.');
    if (!Number.isFinite(value(amount.value)) || value(amount.value) <= 0) return off('Nhập tiền cược lớn hơn 0.');
    if (![tp,sl].every(e=>Number.isFinite(value(e.value))&&value(e.value)>0)) return off('TP và SL phải lớn hơn 0.');
    const c = controls();
    if (!c || !/\/casino\/games\/limbo\/?$/.test(location.pathname)) return off('Mở một bảng Auto Limbo trong tab này.');
    enabled = true; seenRunning = false; idleAt = 0; cycles = 0;
    currency = c.input.getAttribute('data-bet-amount-active-currency'); lastButton = c.button;
    amount.disabled = tp.disabled = sl.disabled = true; toggle.textContent = 'Tắt tự chạy lại'; status.textContent = 'Đang theo dõi; bạn tự bắt đầu lượt đầu trên game.';
  });
  // Capture manual Stop before the site's handler changes the button state.
  document.addEventListener('click', event => {
    if (!enabled || !event.isTrusted) return;
    const button = event.target.closest?.('[data-testid="auto-bet-button"]');
    if (button && button.getAttribute('data-autobet-status') !== 'start') off('Bạn đã bấm Dừng; tự chạy lại đã tắt.');
  }, true);
  setInterval(() => {
    if (!enabled) return;
    if (!/\/casino\/games\/limbo\/?$/.test(location.pathname)) return off('Đã rời Limbo; tự chạy lại đã tắt.');
    const c = controls();
    if (!c || c.button !== lastButton) return off('Giao diện thay đổi; bật lại theo dõi sau khi kiểm tra.');
    if (c.input.getAttribute('data-bet-amount-active-currency') !== currency) return off('Đã đổi loại tiền; tự chạy lại đã tắt.');
    if ([...document.querySelectorAll('[role="alert"]')].some(e => visible(e) && /lỗi|không đủ|thất bại|error|insufficient|failed|limit exceeded/i.test(e.textContent))) return off('Trang báo lỗi; tự chạy lại đã tắt để bạn kiểm tra.');
    const state = c.button.getAttribute('data-autobet-status');
    const text = c.button.textContent.trim();
    const running = /Dừng Cược Tự Động|Stop Autobet/i.test(text);
    const idle = state === 'start' && /Bắt Đầu Cược Tự Động|Start Autobet/i.test(text);
    if (running) { seenRunning = true; preparingAt=0; awaiting = 0; idleAt = 0; status.textContent = `Auto đang chạy · đã chạy lại ${cycles} lần`; return; }
    if (awaiting) { if (Date.now() - awaiting > 10000) off('Không xác nhận được Auto bắt đầu; đã tắt, không bấm lại.'); return; }
    if (!idle || c.button.disabled || [c.input,c.tp,c.sl].some(e=>e.disabled)) { idleAt = 0; return; }
    if (!seenRunning) return;
    if (!idleAt) { idleAt = Date.now(); status.textContent = 'Lượt đã kết thúc · chờ 2 giây để chạy lại'; return; }
    if (Date.now() - idleAt < 2000) return;
    if (!preparingAt) preparingAt=Date.now();
    if (Date.now()-preparingAt>10000) return off('Trang không giữ cấu hình; đã tắt, không bắt đầu.');
    const settings=[[c.input,value(amount.value)],[c.tp,value(tp.value)],[c.sl,value(sl.value)]];
    let changed=false;
    for (const [input,target] of settings) if (!input.value.trim() || !Number.isFinite(value(input.value)) || Math.abs(value(input.value)-target)>1e-10) {
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
      setter.call(input, String(target));
      input.dispatchEvent(new Event('input', {bubbles: true}));
      input.dispatchEvent(new Event('change', {bubbles: true}));changed=true;
    }
    if(changed){idleAt=Date.now();return;}
    if (!settings.every(([input])=>input.checkValidity())) return off('Tiền cược/TP/SL không hợp lệ theo giới hạn trang.');
    seenRunning = false; idleAt = 0; awaiting = Date.now(); cycles++;
    c.button.click();
  }, 250);
})();
