const tabs=document.getElementById('tabs'),app=document.getElementById('app'),connection=document.getElementById('connection');
let source='',busy=false,mounted=false,queue=Promise.resolve();
async function refresh(){
 const all=(await chrome.tabs.query({url:'https://stake1022.com/*'})).filter(t=>/\/casino\/games\/limbo\/?(?:\?|$)/.test(t.url||''));
 const previous=source;
 tabs.replaceChildren(new Option('Chọn tab Limbo',''),...all.map(t=>new Option(`Limbo · tab ${t.id}${t.active?' · đang mở':''}`,String(t.id))));
 if(all.some(t=>String(t.id)===previous))source=previous;else source=String(all.find(t=>t.active)?.id|| (all.length===1?all[0].id:''));
 tabs.value=source;if(previous!==source){mounted=false;app.replaceChildren()}
}
function values(){return Object.fromEntries([...app.querySelectorAll('input[id],select[id]')].map(e=>[e.id,e.value]));}
function sync(action){
 if(!source||(!action&&busy))return;
 const selected=source,config=action?values():undefined;
 queue=queue.then(()=>perform(action,selected,config)).catch(()=>{});return queue;
}
async function perform(action,selected,config){
 if(selected!==source)return;busy=true;
 try{
  const result=await chrome.tabs.sendMessage(Number(selected),{type:'limbo-panel',action,config});
  if(selected!==source)return;
  if(!result)throw Error('missing');
  if(!mounted){app.innerHTML=result.html;mounted=true;}
  for(const [key,value]of Object.entries(result.config)){const e=app.querySelector('#'+key);if(e){if(document.activeElement!==e||result.disabled)e.value=value;e.disabled=result.disabled}}
  app.querySelector('output').textContent=result.status;app.querySelector('#toggle').textContent=result.toggle;
  connection.textContent=result.ready?'Đã kết nối tab Limbo. Tool chạy trong tab kể cả khi đóng panel.':'Đang tải cấu hình…';
 }catch{connection.textContent='Chưa kết nối. Reload tiện ích rồi F5 tab Limbo; sau đó mở lại panel.';app.replaceChildren();mounted=false}
 finally{busy=false}
}
tabs.onchange=()=>{source=tabs.value;mounted=false;app.replaceChildren();void sync()};
app.addEventListener('change',()=>void sync('save'));
app.addEventListener('click',event=>{const id=event.target.closest('button')?.id;if(['toggle','reloadNow','telegram'].includes(id))void sync(id)});
chrome.tabs.onRemoved.addListener(()=>void refresh());
chrome.tabs.onUpdated.addListener((_id,change)=>{if(change.status==='complete')void refresh()});
void refresh().then(()=>sync());setInterval(()=>void sync(),750);
